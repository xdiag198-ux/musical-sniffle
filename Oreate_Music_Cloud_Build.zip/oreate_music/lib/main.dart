import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = 'https://ivubrpaaauzbdwzhwwtu.supabase.co';
const supabasePublishableKey = 'sb_publishable_1DIWwkBWMSzsbnex6VU5fw_QcfEaFVZ';
const bg = Color(0xFF0D100F);
const panel = Color(0xFF191F1C);
const green = Color(0xFF8BE28F);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabasePublishableKey);
  await LocalStore.database;
  runApp(const OreateApp());
}

final supabase = Supabase.instance.client;

class Track {
  const Track({required this.id, required this.title, required this.artist, required this.url, this.localPath, this.isDownloaded = false});
  final int id;
  final String title, artist, url;
  final String? localPath;
  final bool isDownloaded;
  factory Track.fromRemote(Map<String, dynamic> m) => Track(id: (m['id'] as num).toInt(), title: (m['title'] ?? 'Без названия').toString(), artist: (m['artist'] ?? 'Неизвестный исполнитель').toString(), url: (m['audio_url'] ?? '').toString());
  factory Track.fromLocal(Map<String, Object?> m) => Track(id: m['id'] as int, title: m['title'] as String, artist: m['artist'] as String, url: m['url'] as String, localPath: m['localPath'] as String?, isDownloaded: (m['isDownloaded'] as int? ?? 0) == 1);
}

class LocalStore {
  static Database? _db;
  static Future<Database> get database async {
    if (_db != null) return _db!;
    final root = await getDatabasesPath();
    _db = await openDatabase(p.join(root, 'oreate_music.db'), version: 1, onCreate: (db, _) async {
      await db.execute('CREATE TABLE tracks (id INTEGER PRIMARY KEY, title TEXT NOT NULL, artist TEXT NOT NULL, url TEXT NOT NULL, localPath TEXT, isDownloaded INTEGER NOT NULL DEFAULT 0)');
    });
    return _db!;
  }
  static Future<void> cache(List<Track> tracks) async {
    final db = await database; final batch = db.batch();
    for (final t in tracks) {
      batch.rawInsert('INSERT INTO tracks(id,title,artist,url) VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,artist=excluded.artist,url=excluded.url', [t.id,t.title,t.artist,t.url]);
    }
    await batch.commit(noResult: true);
  }
  static Future<List<Track>> all({bool offlineOnly = false}) async {
    final rows = await (await database).query('tracks', where: offlineOnly ? 'isDownloaded=1' : null, orderBy: 'id');
    return rows.map(Track.fromLocal).where((t) => !t.isDownloaded || (t.localPath != null && File(t.localPath!).existsSync())).toList();
  }
  static Future<void> markDownloaded(int id, String path) async => (await database).update('tracks', {'localPath':path,'isDownloaded':1}, where:'id=?', whereArgs:[id]);
}

class MusicRepository {
  static Future<List<Track>> fetch() async {
    final rows = await supabase.from('tracks').select('id,title,artist,audio_url').order('id');
    final tracks = (rows as List).map((e) => Track.fromRemote(Map<String,dynamic>.from(e))).where((t) => t.url.isNotEmpty).toList();
    await LocalStore.cache(tracks);
    return LocalStore.all();
  }
}

class OreateApp extends StatelessWidget {
  const OreateApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(debugShowCheckedModeBanner:false, title:'Oreate Music', theme:ThemeData(brightness:Brightness.dark, scaffoldBackgroundColor:bg, colorScheme:const ColorScheme.dark(primary:green,surface:panel), useMaterial3:true, fontFamily:'Roboto'), home:const AuthGate());
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override Widget build(BuildContext context) => StreamBuilder<AuthState>(stream:supabase.auth.onAuthStateChange, builder:(context, snap) { final user=supabase.auth.currentUser; if (user == null) return const AuthScreen(); return const MusicHome(); });
}

class AuthScreen extends StatefulWidget { const AuthScreen({super.key}); @override State<AuthScreen> createState()=>_AuthScreenState(); }
class _AuthScreenState extends State<AuthScreen> with SingleTickerProviderStateMixin {
  late final TabController tabs; final name=TextEditingController(), email=TextEditingController(), pass=TextEditingController(), confirm=TextEditingController(); bool busy=false, obscure=true, pendingConfirmation=false; String? notice; bool success=false;
  @override void initState(){super.initState();tabs=TabController(length:2,vsync:this);}
  @override void dispose(){tabs.dispose();name.dispose();email.dispose();pass.dispose();confirm.dispose();super.dispose();}
  void message(String s,{bool ok=false}){if(mounted)setState(()=>{notice=s,success=ok});}
  Future<void> run(Future<void> Function() action) async {FocusScope.of(context).unfocus();setState(()=>{busy=true,notice=null});try{await action();}on AuthException catch(e){message(_authError(e.message));}catch(e){message('Не удалось выполнить запрос. Проверьте подключение и повторите попытку.');}finally{if(mounted)setState(()=>busy=false);}}
  String _authError(String s){final x=s.toLowerCase();if(x.contains('already registered')||x.contains('already exists'))return 'Аккаунт с таким email уже существует.';if(x.contains('invalid login'))return 'Неверный email или пароль.';if(x.contains('email not confirmed'))return 'Сначала подтвердите email по ссылке из письма.';if(x.contains('password'))return 'Пароль должен содержать не менее 6 символов.';if(x.contains('rate limit'))return 'Слишком много запросов. Попробуйте позже.';return s;}
  Future<void> submitLogin() async {if(email.text.trim().isEmpty||pass.text.isEmpty){message('Заполните email и пароль.');return;}await run(() async {await supabase.auth.signInWithPassword(email:email.text.trim(),password:pass.text);});}
  Future<void> submitSignup() async {if(name.text.trim().length<2){message('Введите имя (минимум 2 символа).');return;}if(!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(email.text.trim())){message('Введите корректный email.');return;}if(pass.text.length<6){message('Пароль должен содержать минимум 6 символов.');return;}if(pass.text!=confirm.text){message('Пароли не совпадают.');return;}await run(() async {final r=await supabase.auth.signUp(email:email.text.trim(),password:pass.text,data:{'display_name':name.text.trim(),'full_name':name.text.trim()});if(r.session==null){pendingConfirmation=true;message('Письмо подтверждения отправлено на ${email.text.trim()}. Откройте его, затем войдите.',ok:true);}});}
  Future<void> resend() async {await run(() async {await supabase.auth.resend(type: OtpType.signup,email:email.text.trim());message('Письмо подтверждения отправлено повторно.',ok:true);});}
  Future<void> reset() async {if(email.text.trim().isEmpty){message('Сначала укажите email.');return;}await run(() async {await supabase.auth.resetPasswordForEmail(email.text.trim());message('Ссылка для восстановления отправлена на почту.',ok:true);});}
  InputDecoration deco(String label,IconData icon)=>InputDecoration(labelText:label,prefixIcon:Icon(icon,color:green),filled:true,fillColor:panel,border:OutlineInputBorder(borderRadius:BorderRadius.circular(16),borderSide:BorderSide.none),focusedBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(16),borderSide:const BorderSide(color:green)));
  Widget field(TextEditingController c,String label,IconData icon,{bool password=false})=>Padding(padding:const EdgeInsets.only(bottom:13),child:TextField(controller:c,obscureText:password&&obscure,keyboardType:label=='Email' ? TextInputType.emailAddress:TextInputType.text,decoration:deco(label,icon).copyWith(suffixIcon:password?IconButton(onPressed:()=>setState(()=>obscure=!obscure),icon:Icon(obscure?Icons.visibility_off:Icons.visibility)):null)));
  @override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:440),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[const SizedBox(height:28),const Icon(Icons.graphic_eq_rounded,color:green,size:58),const SizedBox(height:12),const Text('OREATE',textAlign:TextAlign.center,style:TextStyle(fontSize:30,fontWeight:FontWeight.w900,letterSpacing:5)),const SizedBox(height:8),const Text('Музыка, которая всегда с тобой',textAlign:TextAlign.center,style:TextStyle(color:Colors.white54)),const SizedBox(height:32),Container(decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(15)),child:TabBar(controller:tabs,indicatorSize:TabBarIndicatorSize.tab,indicator:BoxDecoration(color:const Color(0xFF293B2D),borderRadius:BorderRadius.circular(15)),tabs:const[Tab(text:'Вход'),Tab(text:'Регистрация')]),),const SizedBox(height:20),AnimatedBuilder(animation:tabs,builder:(context,_)=>Column(children:[if(tabs.index==1)field(name,'Имя',Icons.person_outline),field(email,'Email',Icons.email_outlined),field(pass,'Пароль',Icons.lock_outline,password:true),if(tabs.index==1)field(confirm,'Повторите пароль',Icons.lock_reset,password:true),if(tabs.index==0)Align(alignment:Alignment.centerRight,child:TextButton(onPressed:busy?null:reset,child:const Text('Забыли пароль?'))),if(notice!=null)Container(width:double.infinity,padding:const EdgeInsets.all(12),margin:const EdgeInsets.only(bottom:12),decoration:BoxDecoration(color:success?green.withOpacity(.12):Colors.redAccent.withOpacity(.12),borderRadius:BorderRadius.circular(12)),child:Text(notice!,style:TextStyle(color:success?green:Colors.redAccent))),SizedBox(height:52,width:double.infinity,child:FilledButton(onPressed:busy?null:(tabs.index==0?submitLogin:submitSignup),style:FilledButton.styleFrom(backgroundColor:green,foregroundColor:bg,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(16))),child:busy?const SizedBox(width:22,height:22,child:CircularProgressIndicator(strokeWidth:2,color:bg)):Text(tabs.index==0?'ВОЙТИ':'СОЗДАТЬ АККАУНТ',style:const TextStyle(fontWeight:FontWeight.w900,letterSpacing:1)))),if(tabs.index==0&&pendingConfirmation)TextButton(onPressed:busy?null:resend,child:const Text('Отправить письмо подтверждения повторно'))]))]))))));
}

class MusicHome extends StatefulWidget {const MusicHome({super.key});@override State<MusicHome> createState()=>_MusicHomeState();}
class _MusicHomeState extends State<MusicHome> with SingleTickerProviderStateMixin {
  late final TabController tabs;final player=AudioPlayer();List<Track> catalog=[],offline=[];Track? current;bool loading=true,downloading=false;int? downloadingId;double progress=0;String? error;
  @override void initState(){super.initState();tabs=TabController(length:3,vsync:this);load();}
  Future<void> load() async {setState(()=>{loading=true,error=null});try{try{catalog=await MusicRepository.fetch();}catch(e){catalog=await LocalStore.all();if(catalog.isEmpty)rethrow;}offline=await LocalStore.all(offlineOnly:true);if(mounted)setState(()=>loading=false);}catch(e){if(mounted)setState(()=>{loading=false,error:'Не удалось получить каталог. Проверьте подключение к интернету и настройки Supabase.'});}}
  Future<void> play(Track t)async{try{final local=t.isDownloaded&&t.localPath!=null&&await File(t.localPath!).exists();await player.setAudioSource(local?AudioSource.file(t.localPath!):AudioSource.uri(Uri.parse(t.url)));if(mounted)setState(()=>current=t);await player.play();}catch(e){toast('Не удалось воспроизвести трек. Проверьте ссылку на аудиофайл.');}}
  Future<void> download(Track t)async{if(downloading||t.isDownloaded)return;setState(()=>{downloading=true,downloadingId=t.id,progress=0});try{final dir=await getApplicationDocumentsDirectory();final folder=Directory(p.join(dir.path,'music'));await folder.create(recursive:true);final path=p.join(folder.path,'track_${t.id}.mp3');await Dio(BaseOptions(connectTimeout:const Duration(seconds:25),receiveTimeout:const Duration(minutes:5))).download(t.url,path,onReceiveProgress:(a,b){if(mounted&&b>0)setState(()=>progress=a/b);},deleteOnError:true);if(await File(path).length()==0)throw Exception();await LocalStore.markDownloaded(t.id,path);await load();toast('Трек сохранён для офлайн-прослушивания.');}catch(_){toast('Не удалось скачать трек. Проверьте доступность аудиофайла.');}finally{if(mounted)setState(()=>{downloading=false,downloadingId=null,progress=0});}}
  void toast(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s),backgroundColor:panel));
  Future<void> logout()async{await supabase.auth.signOut();}
  Widget trackTile(Track t,{bool isOffline=false})=>Container(margin:const EdgeInsets.symmetric(horizontal:16,vertical:5),decoration:BoxDecoration(color:current?.id==t.id?const Color(0xFF243328):panel,borderRadius:BorderRadius.circular(16)),child:ListTile(onTap:()=>play(t),leading:Container(width:48,height:48,decoration:BoxDecoration(color:const Color(0xFF294331),borderRadius:BorderRadius.circular(12)),child:const Icon(Icons.music_note,color:green)),title:Text(t.title,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w700)),subtitle:Text(t.artist,style:const TextStyle(color:Colors.white54)),trailing:isOffline?const Icon(Icons.offline_pin,color:green):t.isDownloaded?const Icon(Icons.check_circle,color:green):downloadingId==t.id?SizedBox(width:24,height:24,child:CircularProgressIndicator(value:progress==0?null:progress,strokeWidth:2,color:green)):IconButton(onPressed:downloading?null:()=>download(t),icon:const Icon(Icons.download_rounded))));
  Widget list(List<Track> data,{bool isOffline=false})=>data.isEmpty?const Center(child:Text('Пока здесь пусто',style:TextStyle(color:Colors.white54))):RefreshIndicator(color:green,onRefresh:load,child:ListView(padding:const EdgeInsets.only(top:14,bottom:18),children:[Padding(padding:const EdgeInsets.fromLTRB(20,8,20,14),child:Text(isOffline?'Скачано: ${data.length}':'Ваша музыка',style:const TextStyle(fontSize:24,fontWeight:FontWeight.w800))),...data.map((t)=>trackTile(t,isOffline:isOffline))]));
  Widget mini()=>current==null?const SizedBox.shrink():Container(margin:const EdgeInsets.fromLTRB(12,0,12,8),padding:const EdgeInsets.symmetric(horizontal:12,vertical:6),decoration:BoxDecoration(color:const Color(0xFF252C28),borderRadius:BorderRadius.circular(15)),child:StreamBuilder<PlayerState>(stream:player.playerStateStream,builder:(context,s){final playing=s.data?.playing??false;return Row(children:[const Icon(Icons.graphic_eq,color:green),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(current!.title,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.bold)),Text(current!.artist,style:const TextStyle(color:Colors.white54,fontSize:11))])),IconButton(onPressed:()=>player.seekToPrevious(),icon:const Icon(Icons.skip_previous)),IconButton(onPressed:()=>playing?player.pause():player.play(),icon:Icon(playing?Icons.pause_circle:Icons.play_circle,color:green,size:34)),IconButton(onPressed:()=>player.seekToNext(),icon:const Icon(Icons.skip_next))]);}));
  @override Widget build(BuildContext context){return Scaffold(appBar:AppBar(title:const Text('OREATE',style:TextStyle(fontWeight:FontWeight.w900,letterSpacing:3)),actions:[IconButton(tooltip:'Профиль',onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProfileScreen(onLogout:logout))),icon:const Icon(Icons.account_circle_outlined,size:28))],bottom:TabBar(controller:tabs,indicatorColor:green,labelColor:green,unselectedLabelColor:Colors.white54,tabs:const[Tab(text:'Каталог'),Tab(text:'Офлайн'),Tab(text:'Профиль')])),body:loading?const Center(child:CircularProgressIndicator(color:green)):error!=null?Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[Text(error!,textAlign:TextAlign.center),const SizedBox(height:12),FilledButton(onPressed:load,child:const Text('Повторить'))]))):TabBarView(controller:tabs,children:[list(catalog),list(offline,isOffline:true),ProfileScreen(onLogout:logout,embedded:true)]),bottomNavigationBar:SafeArea(top:false,child:mini()));}
  @override void dispose(){tabs.dispose();player.dispose();super.dispose();}
}

class ProfileScreen extends StatefulWidget {const ProfileScreen({super.key,required this.onLogout,this.embedded=false});final Future<void> Function() onLogout;final bool embedded;@override State<ProfileScreen> createState()=>_ProfileScreenState();}
class _ProfileScreenState extends State<ProfileScreen>{late final TextEditingController name;bool saving=false;final colors=[green,Colors.orangeAccent,Colors.lightBlueAccent,Colors.pinkAccent,Colors.deepPurpleAccent];int avatar=0;
  @override void initState(){super.initState();final u=supabase.auth.currentUser!;name=TextEditingController(text:(u.userMetadata?['display_name']??u.userMetadata?['full_name']??'').toString());avatar=((u.userMetadata?['avatar_color'] as num?)?.toInt()??0).clamp(0,4);}
  @override void dispose(){name.dispose();super.dispose();}
  Future<void> save()async{if(name.text.trim().length<2){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Имя должно содержать минимум 2 символа.')));return;}setState(()=>saving=true);try{await supabase.auth.updateUser(UserAttributes(data:{'display_name':name.text.trim(),'full_name':name.text.trim(),'avatar_color':avatar}));if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Профиль обновлён.')));}on AuthException catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.message)));}finally{if(mounted)setState(()=>saving=false);}}
  @override Widget build(BuildContext context){final u=supabase.auth.currentUser!;final display=(u.userMetadata?['display_name']??u.userMetadata?['full_name']??'Пользователь').toString();final body=ListView(padding:const EdgeInsets.all(22),children:[const SizedBox(height:12),Center(child:CircleAvatar(radius:48,backgroundColor:colors[avatar.clamp(0,colors.length-1)],child:Text((display.isNotEmpty?display[0]:'U').toUpperCase(),style:const TextStyle(color:bg,fontSize:36,fontWeight:FontWeight.bold)))),const SizedBox(height:18),const Center(child:Text('Аватар профиля',style:TextStyle(color:Colors.white60))),const SizedBox(height:10),Row(mainAxisAlignment:MainAxisAlignment.center,children:List.generate(colors.length,(i)=>IconButton(onPressed:()=>setState(()=>avatar=i),icon:Icon(Icons.circle,color:colors[i],size:28),selectedIcon:const Icon(Icons.check_circle)))),const SizedBox(height:24),TextField(controller:name,decoration:const InputDecoration(labelText:'Имя пользователя',filled:true,fillColor:panel,border:OutlineInputBorder(borderRadius:BorderRadius.all(Radius.circular(14))))),const SizedBox(height:14),_info('Email',u.email??'—'),_info('Дата регистрации',u.createdAt.isNotEmpty?u.createdAt.substring(0,10):'—'),const SizedBox(height:20),FilledButton(onPressed:saving?null:save,style:FilledButton.styleFrom(backgroundColor:green,foregroundColor:bg),child:saving?const CircularProgressIndicator():const Text('Сохранить изменения')),const SizedBox(height:12),OutlinedButton.icon(onPressed:widget.onLogout,icon:const Icon(Icons.logout),label:const Text('Выйти из аккаунта'),style:OutlinedButton.styleFrom(foregroundColor:Colors.redAccent,side:const BorderSide(color:Colors.redAccent))) ]);return widget.embedded?body:Scaffold(appBar:AppBar(title:const Text('Профиль')),body:body);}
  Widget _info(String title,String value)=>Container(margin:const EdgeInsets.only(top:10),padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(14)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(color:Colors.white54,fontSize:12)),const SizedBox(height:5),Text(value,style:const TextStyle(fontWeight:FontWeight.w600))]));
}
