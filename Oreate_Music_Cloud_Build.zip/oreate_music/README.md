# Oreate Music — облачная сборка Android APK

Это исходный Flutter-проект на основе предоставленных `main.dart` и `pubspec.yaml`. Локально устанавливать Flutter или Android Studio не требуется: Android APK собирается на GitHub Actions.

## Как получить APK только с телефона / через браузер

1. Создайте аккаунт на GitHub и войдите в него.
2. Нажмите **New repository**, назовите репозиторий `oreate-music`, выберите **Private** (рекомендуется) и создайте его.
3. На странице репозитория откройте **Add file → Create new file**. В поле имени файла укажите `.github/workflows/android-apk.yml`.
4. Откройте файл `android-apk.yml` из этого комплекта (или скачайте его отдельно по ссылке, которую дал ChatGPT), скопируйте весь текст и вставьте в редактор GitHub. Нажмите **Commit changes**. Это добавит сценарий сборки в репозиторий.
5. Теперь нажмите **Add file → Upload files** и загрузите в репозиторий один файл `Oreate_Music_Cloud_Build.zip` (сам архив, не распаковывая его). Нажмите **Commit changes**. Workflow автоматически распакует архив и соберёт приложение.
6. Откройте вкладку **Actions**. Дождитесь завершения задачи **Build Android APK** с зелёной отметкой.
7. Откройте завершённый запуск workflow. Внизу страницы, в разделе **Artifacts**, скачайте `oreate-music-release-apk`.
8. Распакуйте скачанный artifact ZIP — внутри будет `app-release.apk`. Откройте APK на телефоне и подтвердите установку из этого источника, если Android попросит.

Если вкладка Actions попросит разрешить workflow, нажмите **I understand my workflows, go ahead and enable them**. Если workflow не стартовал автоматически, откройте **Actions → Build Android APK → Run workflow**.

## Что делает workflow

- Устанавливает Java 17 и актуальный stable Flutter на временной машине GitHub.
- Генерирует стандартные Android/Gradle файлы командой `flutter create` — локальная среда разработки не нужна.
- Выполняет `flutter pub get`.
- Запускает `flutter analyze` и сохраняет его результат в логе. Даже если анализатор найдёт замечания, сборка APK будет предпринята отдельно.
- Собирает `flutter build apk --release` и публикует APK как artifact на 14 дней.

**Важно:** результат сборки пока не существует, пока GitHub Actions реально не выполнит workflow. Этот ZIP содержит исходники и сценарий облачной сборки, а не готовый APK.

## Supabase

Используется существующая таблица `public.tracks`; приложение не создаёт таблицы и не вставляет демонстрационные записи. Для чтения каталога должна быть настроена подходящая RLS SELECT policy. В приложении используется publishable key, не service-role key.

Для регистрации с подтверждением email включите Email provider в Supabase Auth и проверьте шаблон письма и URL Configuration. Для мобильного возврата из письма может понадобиться настроить deep link/redirect под фактический Android application id.

## Состав

- `lib/main.dart` — текущая версия приложения.
- `pubspec.yaml` — зависимости Flutter.
- `.github/workflows/android-apk.yml` — облачная сборка APK.
- `android/app/src/main/AndroidManifest.xml` — разрешение INTERNET и Android activity template.
- `original_main.dart`, `original_pubspec.yaml` — резервные копии предоставленных исходников.

## Честный статус проверки

В среде подготовки архива Flutter SDK и Dart SDK отсутствуют, поэтому здесь не выполнялись `flutter pub get`, `flutter analyze` и фактическая сборка APK. Эти команды запускаются workflow на GitHub; их реальные результаты будут видны в Actions.
