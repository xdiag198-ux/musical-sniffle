import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MusicApp());
}

const String fakeJwtToken =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.demo.music.token';

const Color backgroundColor = Color(0xFF101010);
const Color surfaceColor = Color(0xFF1C1C1C);
const Color accentColor = Color(0xFF1ED760);

class Track {
  const Track({
    required this.id,
    required this.title,
    required this.artist,
    required this.url,
    this.localPath,
    this.isDownloaded = false,
  });

  final int id;
  final String title;
  final String artist;
  final String url;
  final String? localPath;
  final bool isDownloaded;

  factory Track.fromMap(Map<String, Object?> map) => Track(
        id: map['id'] as int,
        title: map['title'] as String,
        artist: map['artist'] as String,
        url: map['url'] as String,
        localPath: map['localPath'] as String?,
        isDownloaded: (map['isDownloaded'] as int? ?? 0) == 1,
      );

  Map<String, Object?> toMap() => {
        'id': id,
        'title': title,
        'artist': artist,
        'url': url,
        'localPath': localPath,
        'isDownloaded': isDownloaded ? 1 : 0,
      };
}

class MockApi {
  static Future<List<Track>> getTracks() async {
    await Future<void>.delayed(const Duration(milliseconds: 350));
    return const [
      Track(
        id: 1,
        title: 'SoundHelix 1',
        artist: 'SoundHelix',
        url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
      ),
      Track(
        id: 2,
        title: 'SoundHelix 2',
        artist: 'SoundHelix',
        url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
      ),
      Track(
        id: 3,
        title: 'SoundHelix 3',
        artist: 'SoundHelix',
        url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
      ),
      Track(
        id: 4,
        title: 'SoundHelix 4',
        artist: 'SoundHelix',
        url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
      ),
    ];
  }
}

class AuthService {
  static String? token;

  static Future<bool> login() async {
    await Future<void>.delayed(const Duration(milliseconds: 200));
    token = fakeJwtToken;
    return token != null;
  }
}

class DatabaseService {
  static Database? _database;

  static Future<Database> get database async {
    if (_database != null) return _database!;

    final dbPath = await getDatabasesPath();
    _database = await openDatabase(
      '$dbPath/music_app.db',
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE tracks (
            id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            artist TEXT NOT NULL,
            url TEXT NOT NULL,
            localPath TEXT,
            isDownloaded INTEGER NOT NULL DEFAULT 0
          )
        ''');
      },
    );
    return _database!;
  }

  static Future<void> saveTracks(List<Track> tracks) async {
    final db = await database;
    final batch = db.batch();
    for (final track in tracks) {
      // Refresh catalog metadata without overwriting download information.
      batch.rawInsert(
        '''
        INSERT INTO tracks (id, title, artist, url, localPath, isDownloaded)
        VALUES (?, ?, ?, ?, NULL, 0)
        ON CONFLICT(id) DO UPDATE SET
          title = excluded.title,
          artist = excluded.artist,
          url = excluded.url
        ''',
        [track.id, track.title, track.artist, track.url],
      );
    }
    await batch.commit(noResult: true);
  }

  static Future<List<Track>> getAllTracks() async {
    final rows = await (await database).query('tracks', orderBy: 'id ASC');
    return rows.map(Track.fromMap).toList();
  }

  static Future<List<Track>> getDownloadedTracks() async {
    final rows = await (await database).query(
      'tracks',
      where: 'isDownloaded = ?',
      whereArgs: [1],
      orderBy: 'id ASC',
    );
    return rows.map(Track.fromMap).toList();
  }

  static Future<void> markDownloaded(int id, String localPath) async {
    await (await database).update(
      'tracks',
      {'localPath': localPath, 'isDownloaded': 1},
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}

class DownloadService {
  static final Dio _dio = Dio(
    BaseOptions(
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(minutes: 5),
      followRedirects: true,
    ),
  );

  static Future<String> download(
    Track track, {
    required ProgressCallback onProgress,
  }) async {
    final documents = await getApplicationDocumentsDirectory();
    final musicDirectory = Directory('${documents.path}/music');
    if (!await musicDirectory.exists()) {
      await musicDirectory.create(recursive: true);
    }

    final filePath = '${musicDirectory.path}/track_${track.id}.mp3';
    await _dio.download(
      track.url,
      filePath,
      onReceiveProgress: onProgress,
      deleteOnError: true,
    );

    final file = File(filePath);
    if (!await file.exists() || await file.length() == 0) {
      throw Exception('Скачанный файл пуст или отсутствует.');
    }
    return filePath;
  }
}

class MusicApp extends StatelessWidget {
  const MusicApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MUSIC',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: backgroundColor,
        colorScheme: const ColorScheme.dark(
          primary: accentColor,
          surface: surfaceColor,
        ),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  final AudioPlayer _player = AudioPlayer();

  List<Track> tracks = [];
  List<Track> downloadedTracks = [];
  Track? currentTrack;

  bool isLoading = true;
  bool isDownloading = false;
  int? downloadingTrackId;
  double downloadProgress = 0;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _initialize();
  }

  Future<void> _initialize() async {
    if (mounted) {
      setState(() {
        isLoading = tracks.isEmpty;
        errorMessage = null;
      });
    }

    try {
      if (!await AuthService.login()) {
        throw Exception('Не удалось выполнить вход.');
      }
      final apiTracks = await MockApi.getTracks();
      await DatabaseService.saveTracks(apiTracks);
      await _refreshTracks();
    } catch (error) {
      if (!mounted) return;
      setState(() {
        errorMessage = 'Не удалось загрузить каталог: $error';
        isLoading = false;
      });
    }
  }

  Future<void> _refreshTracks() async {
    final all = await DatabaseService.getAllTracks();
    final offline = await DatabaseService.getDownloadedTracks();
    if (!mounted) return;
    setState(() {
      tracks = all;
      downloadedTracks = offline;
      isLoading = false;
      errorMessage = null;
    });
  }

  Future<void> _playTrack(Track track) async {
    try {
      final localPath = track.localPath;
      final localFileExists = track.isDownloaded &&
          localPath != null &&
          await File(localPath).exists();

      if (localFileExists) {
        await _player.setAudioSource(AudioSource.file(localPath));
      } else {
        await _player.setAudioSource(
          AudioSource.uri(Uri.parse(track.url)),
        );
      }

      if (!mounted) return;
      setState(() => currentTrack = track);
      await _player.play();
    } catch (error) {
      if (!mounted) return;
      _showMessage('Не удалось воспроизвести трек: $error');
    }
  }

  Future<void> _togglePlayback() async {
    try {
      if (_player.playing) {
        await _player.pause();
      } else if (currentTrack != null) {
        await _player.play();
      }
    } catch (error) {
      if (mounted) _showMessage('Ошибка плеера: $error');
    }
  }

  Future<void> _downloadTrack(Track track) async {
    if (track.isDownloaded || isDownloading) return;

    setState(() {
      isDownloading = true;
      downloadingTrackId = track.id;
      downloadProgress = 0;
    });

    try {
      final localPath = await DownloadService.download(
        track,
        onProgress: (received, total) {
          if (!mounted || total <= 0) return;
          setState(() => downloadProgress = received / total);
        },
      );
      await DatabaseService.markDownloaded(track.id, localPath);
      await _refreshTracks();
      if (mounted) _showMessage('${track.title} сохранён офлайн.');
    } catch (error) {
      if (mounted) _showMessage('Ошибка скачивания: $error');
    } finally {
      if (mounted) {
        setState(() {
          isDownloading = false;
          downloadingTrackId = null;
          downloadProgress = 0;
        });
      }
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: const Color(0xFF303030),
        ),
      );
  }

  Widget _buildDownloadButton(Track track) {
    if (track.isDownloaded) {
      return const Icon(Icons.check_circle, color: accentColor);
    }

    if (downloadingTrackId == track.id) {
      return SizedBox(
        width: 27,
        height: 27,
        child: CircularProgressIndicator(
          value: downloadProgress > 0 ? downloadProgress : null,
          strokeWidth: 2.5,
          color: accentColor,
        ),
      );
    }

    return IconButton(
      tooltip: 'Скачать',
      onPressed: isDownloading ? null : () => _downloadTrack(track),
      icon: const Icon(Icons.download_rounded, color: Colors.white70),
    );
  }

  Widget _buildTrackCard(Track track, {required bool offline}) {
    final selected = currentTrack?.id == track.id;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      decoration: BoxDecoration(
        color: selected ? const Color(0xFF252D27) : surfaceColor,
        borderRadius: BorderRadius.circular(13),
      ),
      child: ListTile(
        onTap: () => _playTrack(track),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
        leading: Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF315B43), Color(0xFF152C20)],
            ),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(
            selected ? Icons.graphic_eq : Icons.music_note_rounded,
            color: accentColor,
            size: 27,
          ),
        ),
        title: Text(
          track.title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontWeight: FontWeight.w600,
            color: selected ? accentColor : Colors.white,
          ),
        ),
        subtitle: Text(
          track.artist,
          style: const TextStyle(color: Colors.white54, fontSize: 12),
        ),
        trailing: offline
            ? const Icon(Icons.offline_pin, color: accentColor)
            : _buildDownloadButton(track),
      ),
    );
  }

  Widget _buildEmptyState(
    IconData icon,
    String title, {
    String subtitle = '',
  }) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 62, color: Colors.white24),
          const SizedBox(height: 16),
          Text(
            title,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          if (subtitle.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(subtitle, style: const TextStyle(color: Colors.white54)),
          ],
        ],
      ),
    );
  }

  Widget _buildCatalog() {
    if (tracks.isEmpty) {
      return _buildEmptyState(Icons.music_off, 'Каталог пуст');
    }
    return RefreshIndicator(
      color: accentColor,
      onRefresh: _initialize,
      child: ListView(
        padding: const EdgeInsets.only(top: 12, bottom: 20),
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(20, 12, 20, 16),
            child: Text(
              'Рекомендуемое',
              style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold),
            ),
          ),
          ...tracks.map((track) => _buildTrackCard(track, offline: false)),
        ],
      ),
    );
  }

  Widget _buildOffline() {
    if (downloadedTracks.isEmpty) {
      return _buildEmptyState(
        Icons.download_for_offline_outlined,
        'Здесь пока ничего нет',
        subtitle: 'Скачанные композиции появятся здесь',
      );
    }
    return ListView(
      padding: const EdgeInsets.only(top: 12, bottom: 20),
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
          child: Text(
            'Скачано: ${downloadedTracks.length}',
            style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold),
          ),
        ),
        ...downloadedTracks.map(
          (track) => _buildTrackCard(track, offline: true),
        ),
      ],
    );
  }

  Widget _buildMiniPlayer() {
    if (currentTrack == null) return const SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.fromLTRB(10, 0, 10, 5),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: const Color(0xFF282828),
        borderRadius: BorderRadius.circular(12),
      ),
      child: StreamBuilder<PlayerState>(
        stream: _player.playerStateStream,
        builder: (context, snapshot) {
          final playerState = snapshot.data;
          final playing = playerState?.playing ?? false;
          final processing = playerState?.processingState;
          final loading = processing == ProcessingState.loading ||
              processing == ProcessingState.buffering;

          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              StreamBuilder<Duration>(
                stream: _player.positionStream,
                builder: (context, positionSnapshot) {
                  final position = positionSnapshot.data ?? Duration.zero;
                  final duration = _player.duration ?? Duration.zero;
                  final progress = duration.inMilliseconds > 0
                      ? (position.inMilliseconds / duration.inMilliseconds)
                          .clamp(0.0, 1.0)
                      : 0.0;
                  return LinearProgressIndicator(
                    value: progress,
                    minHeight: 2,
                    backgroundColor: Colors.white12,
                    valueColor:
                        const AlwaysStoppedAnimation<Color>(accentColor),
                  );
                },
              ),
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          currentTrack!.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                          ),
                        ),
                        Text(
                          currentTrack!.artist,
                          style: const TextStyle(
                            color: Colors.white54,
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (loading)
                    const Padding(
                      padding: EdgeInsets.all(12),
                      child: SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: accentColor,
                        ),
                      ),
                    )
                  else
                    IconButton(
                      onPressed: _togglePlayback,
                      icon: Icon(
                        playing
                            ? Icons.pause_rounded
                            : Icons.play_arrow_rounded,
                        size: 32,
                        color: accentColor,
                      ),
                    ),
                ],
              ),
            ],
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: backgroundColor,
        title: const Row(
          children: [
            Icon(Icons.graphic_eq, color: accentColor, size: 29),
            SizedBox(width: 9),
            Text(
              'MUSIC',
              style: TextStyle(
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
                fontSize: 21,
              ),
            ),
          ],
        ),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: accentColor,
          indicatorWeight: 3,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white54,
          tabs: const [
            Tab(text: 'Обзор (API)'),
            Tab(text: 'Скачанные (Офлайн)'),
          ],
        ),
      ),
      body: isLoading
          ? const Center(
              child: CircularProgressIndicator(color: accentColor),
            )
          : errorMessage != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.error_outline,
                          size: 50,
                          color: Colors.redAccent,
                        ),
                        const SizedBox(height: 15),
                        Text(errorMessage!, textAlign: TextAlign.center),
                        const SizedBox(height: 15),
                        ElevatedButton(
                          onPressed: _initialize,
                          child: const Text('Повторить'),
                        ),
                      ],
                    ),
                  ),
                )
              : TabBarView(
                  controller: _tabController,
                  children: [_buildCatalog(), _buildOffline()],
                ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: _buildMiniPlayer(),
      ),
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    _player.dispose();
    super.dispose();
  }
}
